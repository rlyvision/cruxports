# TaskCommander

TaskCommander is a desktop system monitor, lightweight, written in C + GTK4.

Show live:

- CPU: model, family, estimated generation, usage, temperature, core/thread count
- RAM: usage, total/used, memory paging traffic
- Storage: name, model, firmware, filesystem, mountpoint, usage, read/write throughput, temperature when there is a sensor
- Network: RX/TX traffic per interface
- Fans: RPM from hwmon
- GPU: vendor, name detected, usage when the kernel exposes `gpu_busy_percent', temperature when it exists

Build:

```bash
make
```

Run:

```bash
./taskcommander
```

Notes:

- The application reads directly from `/proc' and `/sys', without third-party dependencies.
- Some metrics depend on the sensors exposed by the system kernel.
