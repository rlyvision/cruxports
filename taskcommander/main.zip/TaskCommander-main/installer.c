#include "taskcommander.h"

#include <errno.h>
#include <glib/gstdio.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static gboolean ensure_parent_dir(const char *path) {
    char *dir = g_path_get_dirname(path);
    gboolean ok = g_mkdir_with_parents(dir, 0755) == 0;
    g_free(dir);
    return ok;
}

static gboolean current_executable_path(char *out, size_t size) {
    char *link = g_file_read_link("/proc/self/exe", NULL);
    if (!link) return FALSE;
    g_strlcpy(out, link, size);
    g_free(link);
    return TRUE;
}

static gboolean copy_file_to(const char *src, const char *dst, GError **error) {
    gchar *contents = NULL;
    gsize length = 0;
    if (!g_file_get_contents(src, &contents, &length, error)) {
        return FALSE;
    }
    if (!ensure_parent_dir(dst)) {
        g_set_error(error, G_FILE_ERROR, g_file_error_from_errno(errno), "Failed to create parent directory for %s", dst);
        g_free(contents);
        return FALSE;
    }
    gboolean ok = g_file_set_contents(dst, contents, length, error);
    g_free(contents);
    if (!ok) return FALSE;
    if (g_chmod(dst, 0755) != 0) {
        g_set_error(error, G_FILE_ERROR, g_file_error_from_errno(errno), "Failed to mark %s executable", dst);
        return FALSE;
    }
    return TRUE;
}

static gboolean write_desktop_entry(const char *binary_path, const char *desktop_path, GError **error) {
    if (!ensure_parent_dir(desktop_path)) {
        g_set_error(error, G_FILE_ERROR, g_file_error_from_errno(errno), "Failed to create desktop entry directory");
        return FALSE;
    }

    gchar *desktop = g_strdup_printf(
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Version=1.0\n"
        "Name=TaskCommander\n"
        "Comment=Lightweight system monitor\n"
        "Exec=%s\n"
        "Terminal=false\n"
        "Categories=System;Monitor;Utility;\n"
        "Keywords=system;monitor;performance;hardware;\n"
        "StartupNotify=true\n"
        "Icon=utilities-system-monitor\n",
        binary_path
    );
    gboolean ok = g_file_set_contents(desktop_path, desktop, -1, error);
    g_free(desktop);
    return ok;
}

int taskcommander_install(void) {
    char exe_path[PATH_MAX];
    if (!current_executable_path(exe_path, sizeof(exe_path))) {
        g_printerr("Failed to resolve current executable path\n");
        return 1;
    }

    const char *home = g_get_home_dir();
    char *install_dir = g_build_filename(home, ".local", "bin", NULL);
    char *binary_path = g_build_filename(install_dir, "taskcommander", NULL);
    char *desktop_path = g_build_filename(home, ".local", "share", "applications", "taskcommander.desktop", NULL);

    GError *error = NULL;
    gboolean ok = copy_file_to(exe_path, binary_path, &error);
    if (ok) ok = write_desktop_entry(binary_path, desktop_path, &error);

    if (!ok) {
        g_printerr("Install failed: %s\n", error ? error->message : "unknown error");
        g_clear_error(&error);
        g_free(install_dir);
        g_free(binary_path);
        g_free(desktop_path);
        return 1;
    }

    g_print("Installed TaskCommander to %s and created launcher %s\n", binary_path, desktop_path);
    g_free(install_dir);
    g_free(binary_path);
    g_free(desktop_path);
    return 0;
}

int taskcommander_remove(void) {
    const char *home = g_get_home_dir();
    char *binary_path = g_build_filename(home, ".local", "bin", "taskcommander", NULL);
    char *desktop_path = g_build_filename(home, ".local", "share", "applications", "taskcommander.desktop", NULL);

    if (g_file_test(binary_path, G_FILE_TEST_EXISTS) && g_remove(binary_path) != 0) {
        g_printerr("Failed to remove %s\n", binary_path);
        g_free(binary_path);
        g_free(desktop_path);
        return 1;
    }
    if (g_file_test(desktop_path, G_FILE_TEST_EXISTS) && g_remove(desktop_path) != 0) {
        g_printerr("Failed to remove %s\n", desktop_path);
        g_free(binary_path);
        g_free(desktop_path);
        return 1;
    }

    g_print("Removed TaskCommander launcher and installed binary\n");
    g_free(binary_path);
    g_free(desktop_path);
    return 0;
}
