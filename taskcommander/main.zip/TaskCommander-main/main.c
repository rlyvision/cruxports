#include "taskcommander.h"

int main(int argc, char **argv) {
    if (argc > 1) {
        if (g_strcmp0(argv[1], "--install") == 0) {
            return taskcommander_install();
        }
        if (g_strcmp0(argv[1], "--remove") == 0) {
            return taskcommander_remove();
        }
    }
    return taskcommander_run(argc, argv);
}
