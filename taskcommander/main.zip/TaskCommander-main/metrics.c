#include "taskcommander.h"

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <ifaddrs.h>
#include <inttypes.h>
#include <limits.h>
#include <math.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/statvfs.h>
#include <unistd.h>

static char *read_text_file(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return NULL;

    size_t cap = 4096;
    size_t len = 0;
    char *buf = calloc(cap, 1);
    if (!buf) {
        fclose(f);
        return NULL;
    }

    while (!feof(f)) {
        if (len + 1024 >= cap) {
            cap *= 2;
            char *grown = realloc(buf, cap);
            if (!grown) {
                free(buf);
                fclose(f);
                return NULL;
            }
            buf = grown;
        }
        size_t n = fread(buf + len, 1, cap - len - 1, f);
        len += n;
        if (ferror(f)) {
            free(buf);
            fclose(f);
            return NULL;
        }
    }

    buf[len] = '\0';
    fclose(f);
    return buf;
}

static bool read_first_line(const char *path, char *out, size_t size) {
    FILE *f = fopen(path, "r");
    if (!f) return false;
    if (!fgets(out, (int)size, f)) {
        fclose(f);
        return false;
    }
    fclose(f);
    out[strcspn(out, "\r\n")] = '\0';
    return true;
}

static bool read_u64_file(const char *path, uint64_t *value) {
    char line[128];
    if (!read_first_line(path, line, sizeof(line))) return false;

    errno = 0;
    char *end = NULL;
    unsigned long long v = strtoull(line, &end, 10);
    if (errno != 0 || end == line) return false;
    *value = (uint64_t)v;
    return true;
}

static double clamp_percent(double value) {
    if (value < 0.0) return 0.0;
    if (value > 100.0) return 100.0;
    return value;
}

static void copy_trimmed(char *dst, size_t dst_size, const char *src) {
    while (*src && isspace((unsigned char)*src)) src++;
    g_strlcpy(dst, src, dst_size);
    size_t len = strlen(dst);
    while (len > 0 && isspace((unsigned char)dst[len - 1])) dst[--len] = '\0';
}

static double celsius_from_millideg(uint64_t value) {
    return value > 0 ? (double)value / 1000.0 : -1.0;
}

static void push_history(AppState *state, PanelType panel, double value) {
    size_t idx = state->history_head[panel];
    state->history[panel][idx] = value;
    state->history_head[panel] = (idx + 1) % HISTORY_SIZE;
    if (state->history_len[panel] < HISTORY_SIZE) state->history_len[panel]++;
}

static bool dirname_match_prefix(const char *name, const char *prefix) {
    return g_str_has_prefix(name, prefix);
}

static double read_hwmon_temp_for_device(const char *device_path) {
    char hwmon_root[PATH_MAX];
    g_snprintf(hwmon_root, sizeof(hwmon_root), "%s/hwmon", device_path);
    DIR *dir = opendir(hwmon_root);
    if (!dir) return -1.0;

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char path[PATH_MAX];
        g_snprintf(path, sizeof(path), "%s/%s/temp1_input", hwmon_root, entry->d_name);
        uint64_t value = 0;
        if (read_u64_file(path, &value)) {
            closedir(dir);
            return celsius_from_millideg(value);
        }
    }

    closedir(dir);
    return -1.0;
}

static void update_cpu_info(Metrics *m, int refresh_ms) {
    FILE *f = fopen("/proc/stat", "r");
    if (!f) return;

    char line[512];
    if (fgets(line, sizeof(line), f)) {
        uint64_t user, nice, sys, idle, iowait, irq, softirq, steal;
        if (sscanf(line, "cpu %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64,
                   &user, &nice, &sys, &idle, &iowait, &irq, &softirq, &steal) == 8) {
            uint64_t total = user + nice + sys + idle + iowait + irq + softirq + steal;
            uint64_t idle_all = idle + iowait;
            if (m->cpu.last_total > 0 && total > m->cpu.last_total) {
                uint64_t delta_total = total - m->cpu.last_total;
                uint64_t delta_idle = idle_all - m->cpu.last_idle;
                m->cpu.usage_percent = clamp_percent((1.0 - (double)delta_idle / (double)delta_total) * 100.0);
            }
            m->cpu.last_total = total;
            m->cpu.last_idle = idle_all;
        }
    }
    fclose(f);

    char *cpuinfo = read_text_file("/proc/cpuinfo");
    if (cpuinfo) {
        char *saveptr = NULL;
        int processors = 0;
        for (char *linep = strtok_r(cpuinfo, "\n", &saveptr); linep; linep = strtok_r(NULL, "\n", &saveptr)) {
            if (g_str_has_prefix(linep, "model name")) {
                char *sep = strchr(linep, ':');
                if (sep && m->cpu.model[0] == '\0') copy_trimmed(m->cpu.model, sizeof(m->cpu.model), sep + 1);
            } else if (g_str_has_prefix(linep, "cpu family")) {
                char *sep = strchr(linep, ':');
                if (sep && m->cpu.family[0] == '\0') copy_trimmed(m->cpu.family, sizeof(m->cpu.family), sep + 1);
            } else if (g_str_has_prefix(linep, "cpu cores")) {
                char *sep = strchr(linep, ':');
                if (sep && m->cpu.cores == 0) m->cpu.cores = atoi(sep + 1);
            } else if (g_str_has_prefix(linep, "processor")) {
                processors++;
            }
        }
        m->cpu.threads = processors;
        free(cpuinfo);
    }

    if (m->cpu.generation[0] == '\0' && m->cpu.model[0] != '\0') {
        const char *mark = strstr(m->cpu.model, "i");
        if (mark) {
            const char *dash = strchr(mark, '-');
            if (dash && isdigit((unsigned char)dash[1])) {
                char genbuf[16] = {0};
                size_t pos = 0;
                for (const char *p = dash + 1; isdigit((unsigned char)*p) && pos < sizeof(genbuf) - 1; ++p) {
                    genbuf[pos++] = *p;
                }
                if (pos >= 4) {
                    genbuf[pos - 3] = '\0';
                    g_snprintf(m->cpu.generation, sizeof(m->cpu.generation), "%sth Gen", genbuf);
                } else if (pos > 0) {
                    g_snprintf(m->cpu.generation, sizeof(m->cpu.generation), "%cth Gen", genbuf[0]);
                }
            }
        }
    }

    m->cpu.temperature_c = -1.0;
    DIR *hwmon = opendir("/sys/class/hwmon");
    if (!hwmon) return;

    struct dirent *entry;
    while ((entry = readdir(hwmon)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char name_path[PATH_MAX];
        char name[64];
        g_snprintf(name_path, sizeof(name_path), "/sys/class/hwmon/%s/name", entry->d_name);
        if (!read_first_line(name_path, name, sizeof(name))) continue;
        if (strstr(name, "coretemp") || strstr(name, "k10temp") || strstr(name, "cpu") || strstr(name, "zenpower")) {
            char temp_path[PATH_MAX];
            uint64_t value = 0;
            g_snprintf(temp_path, sizeof(temp_path), "/sys/class/hwmon/%s/temp1_input", entry->d_name);
            if (read_u64_file(temp_path, &value)) {
                m->cpu.temperature_c = celsius_from_millideg(value);
                break;
            }
        }
    }
    closedir(hwmon);
    (void)refresh_ms;
}

static void update_memory_info(AppState *state, int refresh_ms) {
    FILE *f = fopen("/proc/meminfo", "r");
    if (!f) return;

    char key[64];
    uint64_t value = 0;
    char unit[32];
    uint64_t mem_total = 0, mem_available = 0, swap_total = 0, swap_free = 0;
    while (fscanf(f, "%63[^:]: %" SCNu64 " %31s\n", key, &value, unit) == 3) {
        if (strcmp(key, "MemTotal") == 0) mem_total = value;
        else if (strcmp(key, "MemAvailable") == 0) mem_available = value;
        else if (strcmp(key, "SwapTotal") == 0) swap_total = value;
        else if (strcmp(key, "SwapFree") == 0) swap_free = value;
    }
    fclose(f);

    state->metrics.memory.total_kb = mem_total + swap_total;
    state->metrics.memory.available_kb = mem_available + swap_free;
    state->metrics.memory.used_kb = state->metrics.memory.total_kb - state->metrics.memory.available_kb;
    if (state->metrics.memory.total_kb > 0) {
        state->metrics.memory.used_percent = clamp_percent(((double)state->metrics.memory.used_kb / (double)state->metrics.memory.total_kb) * 100.0);
    }

    f = fopen("/proc/vmstat", "r");
    if (!f) return;

    uint64_t pgpgin = 0, pgpgout = 0;
    while (fscanf(f, "%63s %" SCNu64 "\n", key, &value) == 2) {
        if (strcmp(key, "pgpgin") == 0) pgpgin = value;
        else if (strcmp(key, "pgpgout") == 0) pgpgout = value;
    }
    fclose(f);

    if (state->last_mem_in_kb > 0 && refresh_ms > 0) {
        double sec = (double)refresh_ms / 1000.0;
        state->metrics.memory.read_mb_s = ((double)(pgpgin - state->last_mem_in_kb) / 1024.0) / sec;
        state->metrics.memory.write_mb_s = ((double)(pgpgout - state->last_mem_out_kb) / 1024.0) / sec;
    }
    state->last_mem_in_kb = pgpgin;
    state->last_mem_out_kb = pgpgout;
    state->metrics.memory.temp_c = state->metrics.cpu.temperature_c;
}

static bool should_skip_block(const char *name) {
    return g_str_has_prefix(name, "loop") || g_str_has_prefix(name, "ram") || g_str_has_prefix(name, "zram") ||
           g_str_has_prefix(name, "fd") || g_str_has_prefix(name, "sr");
}

static void append_unique_csv(char *buffer, size_t size, const char *value) {
    if (!value || value[0] == '\0') return;
    if (strstr(buffer, value) != NULL) return;
    if (buffer[0] != '\0') g_strlcat(buffer, ", ", size);
    g_strlcat(buffer, value, size);
}

static void detect_storage_transport(const char *disk, StorageInfo *info) {
    char path[PATH_MAX];
    char value[64];

    if (g_str_has_prefix(disk, "nvme")) {
        g_strlcpy(info->transport, "NVMe", sizeof(info->transport));
    } else if (g_str_has_prefix(disk, "mmcblk")) {
        g_strlcpy(info->transport, "SD/MMC", sizeof(info->transport));
    } else if (g_str_has_prefix(disk, "sd")) {
        g_strlcpy(info->transport, "SATA/SCSI", sizeof(info->transport));
    } else if (g_str_has_prefix(disk, "vd") || g_str_has_prefix(disk, "xvd")) {
        g_strlcpy(info->transport, "Virtual disk", sizeof(info->transport));
    } else {
        g_strlcpy(info->transport, "Block device", sizeof(info->transport));
    }

    g_snprintf(path, sizeof(path), "/sys/class/block/%s/removable", disk);
    uint64_t removable = 0;
    if (read_u64_file(path, &removable)) {
        info->removable = removable != 0;
    }

    g_snprintf(path, sizeof(path), "/sys/class/block/%s/device/subsystem", disk);
    char *link_target = g_file_read_link(path, NULL);
    if (link_target) {
        g_strlcpy(value, link_target, sizeof(value));
        const char *base = strrchr(value, '/');
        base = base ? base + 1 : value;
        if (strcmp(base, "usb") == 0) {
            g_strlcpy(info->transport, "USB", sizeof(info->transport));
            info->removable = true;
        } else if (strcmp(base, "nvme") == 0) {
            g_strlcpy(info->transport, "NVMe", sizeof(info->transport));
        } else if (strcmp(base, "mmc") == 0) {
            g_strlcpy(info->transport, "SD/MMC", sizeof(info->transport));
            info->removable = true;
        }
        g_free(link_target);
    }

    g_snprintf(path, sizeof(path), "/sys/class/block/%s/device/vendor", disk);
    if (!read_first_line(path, info->vendor, sizeof(info->vendor))) {
        g_strlcpy(info->vendor, "Unknown vendor", sizeof(info->vendor));
    }

    if (g_str_has_prefix(info->transport, "USB")) {
        char lower_vendor[64];
        char lower_model[128];
        g_strlcpy(lower_vendor, info->vendor, sizeof(lower_vendor));
        g_strlcpy(lower_model, info->model, sizeof(lower_model));
        for (size_t i = 0; lower_vendor[i]; ++i) lower_vendor[i] = (char)g_ascii_tolower(lower_vendor[i]);
        for (size_t i = 0; lower_model[i]; ++i) lower_model[i] = (char)g_ascii_tolower(lower_model[i]);
        if (strstr(lower_vendor, "samsung") || strstr(lower_vendor, "apple") || strstr(lower_vendor, "android") ||
            strstr(lower_model, "iphone") || strstr(lower_model, "phone") || strstr(lower_model, "android")) {
            g_strlcpy(info->transport, "Phone USB", sizeof(info->transport));
            info->removable = true;
        }
    }
}

static int compare_storage_info(const void *lhs, const void *rhs) {
    const StorageInfo *a = lhs;
    const StorageInfo *b = rhs;
    if (a->removable != b->removable) return a->removable ? 1 : -1;
    if (a->used_percent < b->used_percent) return 1;
    if (a->used_percent > b->used_percent) return -1;
    return strcmp(a->name, b->name);
}

static void update_storage_info(Metrics *m, int refresh_ms) {
    StorageInfo previous[MAX_STORAGE];
    size_t previous_count = m->storage_count;
    memcpy(previous, m->storage, sizeof(previous));
    m->storage_count = 0;

    FILE *mounts = fopen("/proc/mounts", "r");
    if (!mounts) return;

    char dev[128], mountpoint[128], fstype[32], opts[256];
    int freq, passno;
    while (fscanf(mounts, "%127s %127s %31s %255s %d %d\n", dev, mountpoint, fstype, opts, &freq, &passno) == 6) {
        if (!g_str_has_prefix(dev, "/dev/")) continue;
        const char *base = strrchr(dev, '/');
        base = base ? base + 1 : dev;
        char disk[64];
        g_strlcpy(disk, base, sizeof(disk));

        size_t len = strlen(disk);
        while (len > 0 && isdigit((unsigned char)disk[len - 1])) disk[--len] = '\0';
        if (len > 0 && disk[len - 1] == 'p') disk[len - 1] = '\0';
        if (should_skip_block(disk)) continue;

        size_t idx = SIZE_MAX;
        for (size_t i = 0; i < m->storage_count; ++i) {
            if (strcmp(m->storage[i].sys_name, disk) == 0) {
                idx = i;
                break;
            }
        }
        if (idx == SIZE_MAX) {
            if (m->storage_count >= MAX_STORAGE) continue;
            idx = m->storage_count++;
            memset(&m->storage[idx], 0, sizeof(StorageInfo));
            for (size_t old = 0; old < previous_count; ++old) {
                if (strcmp(previous[old].sys_name, disk) == 0) {
                    m->storage[idx] = previous[old];
                    break;
                }
            }
            g_strlcpy(m->storage[idx].sys_name, disk, sizeof(m->storage[idx].sys_name));
            g_strlcpy(m->storage[idx].name, disk, sizeof(m->storage[idx].name));
            detect_storage_transport(disk, &m->storage[idx]);

            char path[PATH_MAX];
            g_snprintf(path, sizeof(path), "/sys/class/block/%s/device/model", disk);
            if (!read_first_line(path, m->storage[idx].model, sizeof(m->storage[idx].model))) {
                g_strlcpy(m->storage[idx].model, "Unknown model", sizeof(m->storage[idx].model));
            }
            g_snprintf(path, sizeof(path), "/sys/class/block/%s/device/rev", disk);
            if (!read_first_line(path, m->storage[idx].firmware, sizeof(m->storage[idx].firmware))) {
                g_strlcpy(m->storage[idx].firmware, "n/a", sizeof(m->storage[idx].firmware));
            }
            g_snprintf(path, sizeof(path), "/sys/class/block/%s/device", disk);
            m->storage[idx].temp_c = read_hwmon_temp_for_device(path);
        }

        struct statvfs st;
        if (statvfs(mountpoint, &st) == 0) {
            uint64_t total = (uint64_t)st.f_blocks * st.f_frsize;
            uint64_t available = (uint64_t)st.f_bavail * st.f_frsize;
            uint64_t used = total - available;
            if (used > m->storage[idx].used_bytes) m->storage[idx].used_bytes = used;
            if (total > m->storage[idx].total_bytes) m->storage[idx].total_bytes = total;
            if (m->storage[idx].total_bytes > 0) {
                m->storage[idx].used_percent = clamp_percent(((double)m->storage[idx].used_bytes / (double)m->storage[idx].total_bytes) * 100.0);
            }
            g_strlcpy(m->storage[idx].mountpoint, mountpoint, sizeof(m->storage[idx].mountpoint));
            g_strlcpy(m->storage[idx].fs_type, fstype, sizeof(m->storage[idx].fs_type));
            append_unique_csv(m->storage[idx].mounts, sizeof(m->storage[idx].mounts), mountpoint);
            m->storage[idx].mount_count++;
        }
    }
    fclose(mounts);

    FILE *diskstats = fopen("/proc/diskstats", "r");
    if (!diskstats) return;

    char line[512];
    while (fgets(line, sizeof(line), diskstats)) {
        unsigned major, minor;
        char name[64];
        uint64_t reads, reads_merged, read_sectors, read_ms;
        uint64_t writes, writes_merged, write_sectors, write_ms;
        if (sscanf(line, "%u %u %63s %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64 " %" SCNu64,
                   &major, &minor, name, &reads, &reads_merged, &read_sectors, &read_ms,
                   &writes, &writes_merged, &write_sectors, &write_ms) != 11) {
            continue;
        }
        for (size_t i = 0; i < m->storage_count; ++i) {
            if (strcmp(m->storage[i].sys_name, name) == 0) {
                if (m->storage[i].last_read_sectors > 0 && refresh_ms > 0) {
                    double sec = (double)refresh_ms / 1000.0;
                    m->storage[i].read_kbps = ((double)(read_sectors - m->storage[i].last_read_sectors) * 512.0 / 1024.0) / sec;
                    m->storage[i].write_kbps = ((double)(write_sectors - m->storage[i].last_write_sectors) * 512.0 / 1024.0) / sec;
                }
                m->storage[i].last_read_sectors = read_sectors;
                m->storage[i].last_write_sectors = write_sectors;
                break;
            }
        }
    }
    fclose(diskstats);

    qsort(m->storage, m->storage_count, sizeof(StorageInfo), compare_storage_info);
}

static void update_network_info(Metrics *m, int refresh_ms) {
    NetInfo previous[MAX_NETWORK];
    size_t previous_count = m->network_count;
    memcpy(previous, m->network, sizeof(previous));
    m->network_count = 0;

    FILE *f = fopen("/proc/net/dev", "r");
    if (!f) return;

    char line[512];
    int line_no = 0;
    while (fgets(line, sizeof(line), f)) {
        line_no++;
        if (line_no <= 2) continue;

        char iface[64];
        uint64_t rx, tx;
        if (sscanf(line, " %63[^:]: %" SCNu64 " %*u %*u %*u %*u %*u %*u %*u %" SCNu64, iface, &rx, &tx) != 3) {
            continue;
        }
        if (strcmp(iface, "lo") == 0) continue;
        if (m->network_count >= MAX_NETWORK) continue;

        NetInfo *net = &m->network[m->network_count++];
        memset(net, 0, sizeof(*net));
        g_strlcpy(net->name, iface, sizeof(net->name));
        net->active = true;

        char path[PATH_MAX];
        g_snprintf(path, sizeof(path), "/sys/class/net/%s/operstate", iface);
        if (!read_first_line(path, net->operstate, sizeof(net->operstate))) {
            g_strlcpy(net->operstate, "unknown", sizeof(net->operstate));
        }

        g_snprintf(path, sizeof(path), "/sys/class/net/%s/address", iface);
        if (!read_first_line(path, net->mac, sizeof(net->mac))) {
            g_strlcpy(net->mac, "n/a", sizeof(net->mac));
        }

        g_snprintf(path, sizeof(path), "/sys/class/net/%s/wireless", iface);
        if (access(path, F_OK) == 0 || g_str_has_prefix(iface, "wl")) {
            g_strlcpy(net->kind, "Wi-Fi", sizeof(net->kind));
        } else if (g_str_has_prefix(iface, "en") || g_str_has_prefix(iface, "eth")) {
            g_strlcpy(net->kind, "Ethernet", sizeof(net->kind));
        } else if (g_str_has_prefix(iface, "wwan")) {
            g_strlcpy(net->kind, "Mobile", sizeof(net->kind));
        } else if (g_str_has_prefix(iface, "br") || g_str_has_prefix(iface, "docker")) {
            g_strlcpy(net->kind, "Bridge", sizeof(net->kind));
        } else if (g_str_has_prefix(iface, "tun") || g_str_has_prefix(iface, "tap") || g_str_has_prefix(iface, "wg")) {
            g_strlcpy(net->kind, "Tunnel", sizeof(net->kind));
        } else {
            g_strlcpy(net->kind, "Interface", sizeof(net->kind));
        }

        g_snprintf(path, sizeof(path), "/sys/class/net/%s/device/subsystem", iface);
        char *link_target = g_file_read_link(path, NULL);
        if (link_target) {
            if (strstr(link_target, "/usb")) {
                net->usb_backed = true;
                if (strcmp(net->kind, "Ethernet") == 0) {
                    g_strlcpy(net->kind, "USB Ethernet", sizeof(net->kind));
                }
            }
            g_free(link_target);
        }
        if (strstr(iface, "rndis") || strstr(iface, "usb") || strstr(iface, "enx")) {
            if (net->usb_backed) {
                net->phone_tethering = true;
                g_strlcpy(net->kind, "USB tethering", sizeof(net->kind));
            }
        }

        for (size_t i = 0; i < previous_count; ++i) {
            if (strcmp(previous[i].name, iface) == 0) {
                if (refresh_ms > 0) {
                    double sec = (double)refresh_ms / 1000.0;
                    net->rx_kbps = ((double)(rx - previous[i].last_rx) / 1024.0) / sec;
                    net->tx_kbps = ((double)(tx - previous[i].last_tx) / 1024.0) / sec;
                }
                break;
            }
        }
        net->last_rx = rx;
        net->last_tx = tx;
    }
    fclose(f);

    struct ifaddrs *ifaddr = NULL;
    if (getifaddrs(&ifaddr) == 0) {
        for (struct ifaddrs *ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
            if (!ifa->ifa_name || !ifa->ifa_addr) continue;
            for (size_t i = 0; i < m->network_count; ++i) {
                if (strcmp(m->network[i].name, ifa->ifa_name) != 0) continue;
                char host[INET6_ADDRSTRLEN];
                if (ifa->ifa_addr->sa_family == AF_INET) {
                    struct sockaddr_in *addr4 = (struct sockaddr_in *)ifa->ifa_addr;
                    if (inet_ntop(AF_INET, &addr4->sin_addr, host, sizeof(host)) != NULL) {
                        g_strlcpy(m->network[i].ipv4, host, sizeof(m->network[i].ipv4));
                    }
                } else if (ifa->ifa_addr->sa_family == AF_INET6) {
                    struct sockaddr_in6 *addr6 = (struct sockaddr_in6 *)ifa->ifa_addr;
                    if (inet_ntop(AF_INET6, &addr6->sin6_addr, host, sizeof(host)) != NULL) {
                        append_unique_csv(m->network[i].ipv6, sizeof(m->network[i].ipv6), host);
                    }
                }
                break;
            }
        }
        freeifaddrs(ifaddr);
    }

    for (size_t i = 0; i < m->network_count; ++i) {
        for (size_t j = i + 1; j < m->network_count; ++j) {
            double ai = m->network[i].rx_kbps + m->network[i].tx_kbps;
            double aj = m->network[j].rx_kbps + m->network[j].tx_kbps;
            if (aj > ai) {
                NetInfo tmp = m->network[i];
                m->network[i] = m->network[j];
                m->network[j] = tmp;
            } else if (aj == ai) {
                if (m->network[j].phone_tethering && !m->network[i].phone_tethering) {
                    NetInfo tmp = m->network[i];
                    m->network[i] = m->network[j];
                    m->network[j] = tmp;
                }
            }
        }
    }
}

static void update_fans(Metrics *m) {
    m->fan_count = 0;
    DIR *dir = opendir("/sys/class/hwmon");
    if (!dir) return;

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        char name_path[PATH_MAX];
        char chip_name[64] = "";
        g_snprintf(name_path, sizeof(name_path), "/sys/class/hwmon/%s/name", entry->d_name);
        read_first_line(name_path, chip_name, sizeof(chip_name));

        for (int i = 1; i <= 6 && m->fan_count < MAX_FANS; ++i) {
            char fan_path[PATH_MAX];
            uint64_t rpm = 0;
            g_snprintf(fan_path, sizeof(fan_path), "/sys/class/hwmon/%s/fan%d_input", entry->d_name, i);
            if (read_u64_file(fan_path, &rpm)) {
                FanInfo *fan = &m->fans[m->fan_count++];
                memset(fan, 0, sizeof(*fan));
                g_snprintf(fan->label, sizeof(fan->label), "%s fan%d", chip_name[0] ? chip_name : entry->d_name, i);
                fan->rpm = (int)rpm;
                fan->available = true;
            }
        }
    }
    closedir(dir);
}

static void update_gpus(Metrics *m) {
    m->gpu_count = 0;
    DIR *dir = opendir("/sys/class/drm");
    if (!dir) return;

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (!dirname_match_prefix(entry->d_name, "card") || strchr(entry->d_name, '-')) continue;
        if (m->gpu_count >= MAX_GPU) break;

        GpuInfo *gpu = &m->gpus[m->gpu_count];
        memset(gpu, 0, sizeof(*gpu));
        g_strlcpy(gpu->sys_card, entry->d_name, sizeof(gpu->sys_card));

        char uevent_path[PATH_MAX];
        g_snprintf(uevent_path, sizeof(uevent_path), "/sys/class/drm/%s/device/uevent", entry->d_name);
        char *uevent = read_text_file(uevent_path);
        if (uevent) {
            char *saveptr = NULL;
            for (char *line = strtok_r(uevent, "\n", &saveptr); line; line = strtok_r(NULL, "\n", &saveptr)) {
                if (g_str_has_prefix(line, "DRIVER=")) {
                    g_strlcpy(gpu->vendor, line + 7, sizeof(gpu->vendor));
                } else if (g_str_has_prefix(line, "PCI_ID=") && gpu->name[0] == '\0') {
                    g_snprintf(gpu->name, sizeof(gpu->name), "GPU %s", line + 7);
                }
            }
            free(uevent);
        }

        char vendor_path[PATH_MAX];
        char vendor[32];
        g_snprintf(vendor_path, sizeof(vendor_path), "/sys/class/drm/%s/device/vendor", entry->d_name);
        if (read_first_line(vendor_path, vendor, sizeof(vendor))) {
            if (strcmp(vendor, "0x8086") == 0) g_strlcpy(gpu->vendor, "Intel", sizeof(gpu->vendor));
            else if (strcmp(vendor, "0x1002") == 0) g_strlcpy(gpu->vendor, "AMD", sizeof(gpu->vendor));
            else if (strcmp(vendor, "0x10de") == 0) g_strlcpy(gpu->vendor, "NVIDIA", sizeof(gpu->vendor));
        }
        if (gpu->name[0] == '\0') {
            g_snprintf(gpu->name, sizeof(gpu->name), "%s GPU", gpu->vendor[0] ? gpu->vendor : entry->d_name);
        }

        char busy_path[PATH_MAX];
        uint64_t busy = 0;
        g_snprintf(busy_path, sizeof(busy_path), "/sys/class/drm/%s/device/gpu_busy_percent", entry->d_name);
        gpu->usage_percent = read_u64_file(busy_path, &busy) ? clamp_percent((double)busy) : -1.0;

        char device_path[PATH_MAX];
        g_snprintf(device_path, sizeof(device_path), "/sys/class/drm/%s/device", entry->d_name);
        gpu->temperature_c = read_hwmon_temp_for_device(device_path);
        gpu->available = true;
        m->gpu_count++;
    }
    closedir(dir);
}

void collect_metrics(AppState *state) {
    update_cpu_info(&state->metrics, state->refresh_interval_ms);
    update_memory_info(state, state->refresh_interval_ms);
    update_storage_info(&state->metrics, state->refresh_interval_ms);
    update_network_info(&state->metrics, state->refresh_interval_ms);
    update_fans(&state->metrics);
    update_gpus(&state->metrics);

    push_history(state, PANEL_CPU, state->metrics.cpu.usage_percent);
    push_history(state, PANEL_MEMORY, state->metrics.memory.used_percent);

    double storage_peak = 0.0;
    for (size_t i = 0; i < state->metrics.storage_count; ++i) {
        if (state->metrics.storage[i].used_percent > storage_peak) storage_peak = state->metrics.storage[i].used_percent;
    }
    push_history(state, PANEL_STORAGE, storage_peak);

    double net_peak = 0.0;
    for (size_t i = 0; i < state->metrics.network_count; ++i) {
        double current = state->metrics.network[i].rx_kbps + state->metrics.network[i].tx_kbps;
        if (current > net_peak) net_peak = current;
    }
    push_history(state, PANEL_NETWORK, fmin(100.0, net_peak / 10.0));

    double fan_peak = 0.0;
    for (size_t i = 0; i < state->metrics.fan_count; ++i) {
        if (state->metrics.fans[i].rpm > fan_peak) fan_peak = (double)state->metrics.fans[i].rpm;
    }
    push_history(state, PANEL_FANS, fmin(100.0, fan_peak / 50.0));

    double gpu_peak = 0.0;
    for (size_t i = 0; i < state->metrics.gpu_count; ++i) {
        if (state->metrics.gpus[i].usage_percent > gpu_peak) gpu_peak = state->metrics.gpus[i].usage_percent;
    }
    push_history(state, PANEL_GPU, gpu_peak);
}
