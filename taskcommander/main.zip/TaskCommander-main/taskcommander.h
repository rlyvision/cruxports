#ifndef TASKCOMMANDER_H
#define TASKCOMMANDER_H

#include <gtk/gtk.h>
#include <stdbool.h>
#include <stdint.h>

#define HISTORY_SIZE 120
#define MAX_STORAGE 16
#define MAX_NETWORK 16
#define MAX_FANS 8
#define MAX_GPU 4

typedef struct {
    char name[64];
    char vendor[64];
    char model[128];
    char firmware[64];
    char transport[32];
    char fs_type[32];
    char mountpoint[128];
    char mounts[256];
    size_t mount_count;
    double used_percent;
    double read_kbps;
    double write_kbps;
    double temp_c;
    uint64_t total_bytes;
    uint64_t used_bytes;
    uint64_t last_read_sectors;
    uint64_t last_write_sectors;
    char sys_name[64];
    bool removable;
} StorageInfo;

typedef struct {
    char label[64];
    uint64_t total_kb;
    uint64_t used_kb;
    uint64_t available_kb;
    double used_percent;
    double read_mb_s;
    double write_mb_s;
    double temp_c;
} MemoryInfo;

typedef struct {
    char model[128];
    char family[64];
    char generation[64];
    double usage_percent;
    double temperature_c;
    int cores;
    int threads;
    uint64_t last_total;
    uint64_t last_idle;
} CpuInfo;

typedef struct {
    char name[64];
    char kind[32];
    char operstate[24];
    char mac[32];
    char ipv4[64];
    char ipv6[128];
    double rx_kbps;
    double tx_kbps;
    uint64_t last_rx;
    uint64_t last_tx;
    bool active;
    bool usb_backed;
    bool phone_tethering;
} NetInfo;

typedef struct {
    char label[64];
    int rpm;
    bool available;
} FanInfo;

typedef struct {
    char name[96];
    char vendor[64];
    double usage_percent;
    double temperature_c;
    bool available;
    char sys_card[32];
} GpuInfo;

typedef enum {
    PANEL_CPU,
    PANEL_MEMORY,
    PANEL_STORAGE,
    PANEL_NETWORK,
    PANEL_FANS,
    PANEL_GPU,
    PANEL_COUNT
} PanelType;

typedef enum {
    SECTION_PERFORMANCE,
    SECTION_DEVICES,
    SECTION_SERVICES,
    SECTION_COUNT
} TopSection;

typedef enum {
    VIEW_DEFAULT,
    VIEW_HTOP,
    VIEW_COUNT
} ViewMode;

typedef struct {
    StorageInfo storage[MAX_STORAGE];
    size_t storage_count;
    MemoryInfo memory;
    CpuInfo cpu;
    NetInfo network[MAX_NETWORK];
    size_t network_count;
    FanInfo fans[MAX_FANS];
    size_t fan_count;
    GpuInfo gpus[MAX_GPU];
    size_t gpu_count;
} Metrics;

typedef struct {
    GtkApplication *app;
    GtkWidget *window;
    GtkWidget *sidebar;
    GtkWidget *title_label;
    GtkWidget *subtitle_label;
    GtkWidget *stat_labels[4];
    GtkWidget *detail_view;
    GtkWidget *graph_area;
    GtkWidget *graph_frame;
    GtkWidget *stats_row;
    GtkWidget *sidebar_buttons[PANEL_COUNT];
    GtkWidget *sidebar_extras[PANEL_COUNT];
    GtkWidget *top_buttons[SECTION_COUNT];
    GtkWidget *mode_buttons[VIEW_COUNT];
    Metrics metrics;
    PanelType current_panel;
    TopSection current_section;
    ViewMode current_view;
    double history[PANEL_COUNT][HISTORY_SIZE];
    size_t history_len[PANEL_COUNT];
    size_t history_head[PANEL_COUNT];
    int refresh_interval_ms;
    uint64_t last_mem_in_kb;
    uint64_t last_mem_out_kb;
    guint timer_id;
} AppState;

void collect_metrics(AppState *state);
int taskcommander_run(int argc, char **argv);
int taskcommander_install(void);
int taskcommander_remove(void);

#endif
