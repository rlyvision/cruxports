#include "taskcommander.h"

#include <math.h>

static const char *panel_names[PANEL_COUNT] = {
    "Processor", "Memorie", "Storage", "Network", "Fans", "GPU"
};

static const char *panel_accent[PANEL_COUNT] = {
    "#4BA3FF", "#7AA2F7", "#36D399", "#A855F7", "#C084FC", "#F97316"
};

static const char *panel_badges[PANEL_COUNT] = {
    "CPU", "RAM", "DSK", "NET", "FAN", "GPU"
};

static const char *view_names[VIEW_COUNT] = {
    "Default", "HTOP"
};

static double clamp_percent(double value) {
    if (value < 0.0) return 0.0;
    if (value > 100.0) return 100.0;
    return value;
}

static void human_bytes(uint64_t bytes, char *out, size_t size) {
    static const char *units[] = {"B", "KiB", "MiB", "GiB", "TiB"};
    double value = (double)bytes;
    size_t idx = 0;
    while (value >= 1024.0 && idx < G_N_ELEMENTS(units) - 1) {
        value /= 1024.0;
        idx++;
    }
    g_snprintf(out, size, "%.1f %s", value, units[idx]);
}

static void format_temperature(double temp_c, char *out, size_t size) {
    if (temp_c >= 0.0) g_snprintf(out, size, "%.0f C", temp_c);
    else g_snprintf(out, size, "Unavailable");
}

static GtkWidget *make_stat_row(const char *label, const char *value) {
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 2);
    GtkWidget *top = gtk_label_new(label);
    GtkWidget *bottom = gtk_label_new(value);
    gtk_widget_set_halign(top, GTK_ALIGN_START);
    gtk_widget_set_halign(bottom, GTK_ALIGN_START);
    gtk_widget_add_css_class(top, "dim-label");
    gtk_widget_add_css_class(bottom, "stat-value");
    gtk_box_append(GTK_BOX(box), top);
    gtk_box_append(GTK_BOX(box), bottom);
    return box;
}

static GtkWidget *make_section_label(const char *text) {
    GtkWidget *label = gtk_label_new(text);
    gtk_widget_set_halign(label, GTK_ALIGN_START);
    gtk_widget_add_css_class(label, "section-label");
    return label;
}

static void clear_box(GtkWidget *box) {
    GtkWidget *child = gtk_widget_get_first_child(box);
    while (child) {
        GtkWidget *next = gtk_widget_get_next_sibling(child);
        gtk_box_remove(GTK_BOX(box), child);
        child = next;
    }
}

static GdkRGBA accent_for_value(PanelType panel, double value) {
    GdkRGBA color = {0};
    if (panel == PANEL_FANS) value /= 2.0;
    if (value >= 85.0) gdk_rgba_parse(&color, "#ef4444");
    else if (value >= 65.0) gdk_rgba_parse(&color, "#f59e0b");
    else gdk_rgba_parse(&color, panel_accent[panel]);
    return color;
}

static TopSection section_for_panel(PanelType panel) {
    switch (panel) {
        case PANEL_CPU:
        case PANEL_MEMORY:
        case PANEL_GPU:
            return SECTION_PERFORMANCE;
        case PANEL_STORAGE:
        case PANEL_NETWORK:
            return SECTION_DEVICES;
        case PANEL_FANS:
        default:
            return SECTION_SERVICES;
    }
}

static GtkWidget *make_detail_row(const char *left, const char *right) {
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    GtkWidget *l = gtk_label_new(left);
    GtkWidget *r = gtk_label_new(right);
    gtk_widget_set_hexpand(row, true);
    gtk_widget_set_halign(l, GTK_ALIGN_START);
    gtk_widget_set_halign(r, GTK_ALIGN_END);
    gtk_widget_set_hexpand(l, true);
    gtk_label_set_wrap(GTK_LABEL(l), true);
    gtk_label_set_wrap(GTK_LABEL(r), true);
    gtk_label_set_xalign(GTK_LABEL(l), 0.0f);
    gtk_label_set_xalign(GTK_LABEL(r), 1.0f);
    gtk_widget_add_css_class(l, "detail-key");
    gtk_widget_add_css_class(r, "detail-value");
    gtk_widget_add_css_class(row, "detail-row");
    gtk_box_append(GTK_BOX(row), l);
    gtk_box_append(GTK_BOX(row), r);
    return row;
}

static GtkWidget *make_compact_chip(const char *text) {
    GtkWidget *label = gtk_label_new(text);
    gtk_widget_add_css_class(label, "mini-chip");
    return label;
}

static GtkWidget *make_mono_block(const char *text) {
    GtkWidget *label = gtk_label_new(text);
    gtk_widget_set_halign(label, GTK_ALIGN_START);
    gtk_label_set_xalign(GTK_LABEL(label), 0.0f);
    gtk_label_set_wrap(GTK_LABEL(label), true);
    gtk_widget_add_css_class(label, "mono-block");
    return label;
}

static void set_stats(AppState *state, const char *a, const char *b, const char *c, const char *d) {
    const char *values[4] = {a, b, c, d};
    for (int i = 0; i < 4; ++i) {
        gtk_label_set_text(GTK_LABEL(state->stat_labels[i]), values[i] ? values[i] : "");
    }
}

static void refresh_detail_panel(AppState *state) {
    Metrics *m = &state->metrics;
    clear_box(state->detail_view);
    gtk_label_set_text(GTK_LABEL(state->title_label), panel_names[state->current_panel]);

    char subtitle[256] = "";
    char stat0[64] = "", stat1[64] = "", stat2[64] = "", stat3[64] = "";
    if (state->current_view == VIEW_HTOP) {
        gtk_widget_set_visible(state->stats_row, false);
        gtk_widget_set_visible(state->graph_frame, false);
        g_snprintf(subtitle, sizeof(subtitle), "Compact htop-like telemetry");
        switch (state->current_panel) {
            case PANEL_CPU: {
                char temp[64], block[1024];
                format_temperature(m->cpu.temperature_c, temp, sizeof(temp));
                g_snprintf(block, sizeof(block),
                           "CPU  %.0f%%   TEMP %s   CORES %d   THREADS %d\nMODEL  %s\nFAMILY %s   GEN %s",
                           m->cpu.usage_percent, temp, m->cpu.cores, m->cpu.threads,
                           m->cpu.model[0] ? m->cpu.model : "Unknown",
                           m->cpu.family[0] ? m->cpu.family : "Unknown",
                           m->cpu.generation[0] ? m->cpu.generation : "Unknown");
                gtk_box_append(GTK_BOX(state->detail_view), make_mono_block(block));
                break;
            }
            case PANEL_MEMORY: {
                char total[64], used[64], block[512];
                human_bytes(m->memory.total_kb * 1024ULL, total, sizeof(total));
                human_bytes(m->memory.used_kb * 1024ULL, used, sizeof(used));
                g_snprintf(block, sizeof(block),
                           "MEM  %.0f%%   USED %s   TOTAL %s\nSWAP+RAM IO  IN %.1f MB/s   OUT %.1f MB/s",
                           m->memory.used_percent, used, total, m->memory.read_mb_s, m->memory.write_mb_s);
                gtk_box_append(GTK_BOX(state->detail_view), make_mono_block(block));
                break;
            }
            case PANEL_STORAGE: {
                char block[4096] = "";
                for (size_t i = 0; i < m->storage_count; ++i) {
                    char line[512];
                    g_snprintf(line, sizeof(line), "%-9s %-8s %5.0f%%  R %6.0f  W %6.0f  %s\n",
                               m->storage[i].transport[0] ? m->storage[i].transport : "disk",
                               m->storage[i].name, m->storage[i].used_percent,
                               m->storage[i].read_kbps, m->storage[i].write_kbps,
                               m->storage[i].mounts[0] ? m->storage[i].mounts : "no-mount");
                    g_strlcat(block, line, sizeof(block));
                }
                gtk_box_append(GTK_BOX(state->detail_view), make_mono_block(block[0] ? block : "No storage devices detected"));
                break;
            }
            case PANEL_NETWORK: {
                char block[4096] = "";
                for (size_t i = 0; i < m->network_count; ++i) {
                    char line[512];
                    g_snprintf(line, sizeof(line), "%-14s %-12s RX %7.1f  TX %7.1f  %s\n",
                               m->network[i].name,
                               m->network[i].kind[0] ? m->network[i].kind : "iface",
                               m->network[i].rx_kbps, m->network[i].tx_kbps,
                               m->network[i].ipv4[0] ? m->network[i].ipv4 : m->network[i].operstate);
                    g_strlcat(block, line, sizeof(block));
                }
                gtk_box_append(GTK_BOX(state->detail_view), make_mono_block(block[0] ? block : "No network interfaces detected"));
                break;
            }
            case PANEL_FANS: {
                char block[2048] = "";
                for (size_t i = 0; i < m->fan_count; ++i) {
                    char line[256];
                    g_snprintf(line, sizeof(line), "%-24s %5d RPM\n", m->fans[i].label, m->fans[i].rpm);
                    g_strlcat(block, line, sizeof(block));
                }
                gtk_box_append(GTK_BOX(state->detail_view), make_mono_block(block[0] ? block : "No fan telemetry available"));
                break;
            }
            case PANEL_GPU: {
                char block[2048] = "";
                for (size_t i = 0; i < m->gpu_count; ++i) {
                    char temp[64], line[256];
                    format_temperature(m->gpus[i].temperature_c, temp, sizeof(temp));
                    g_snprintf(line, sizeof(line), "%-20s %-8s UTIL %5.0f%% TEMP %s\n",
                               m->gpus[i].name, m->gpus[i].vendor,
                               m->gpus[i].usage_percent >= 0 ? m->gpus[i].usage_percent : 0.0, temp);
                    g_strlcat(block, line, sizeof(block));
                }
                gtk_box_append(GTK_BOX(state->detail_view), make_mono_block(block[0] ? block : "No GPU telemetry available"));
                break;
            }
            default:
                break;
        }
        set_stats(state, "", "", "", "");
        gtk_label_set_text(GTK_LABEL(state->subtitle_label), subtitle);
        return;
    }

    gtk_widget_set_visible(state->stats_row, true);
    gtk_widget_set_visible(state->graph_frame, true);
    switch (state->current_panel) {
        case PANEL_CPU: {
            char temp[64];
            g_snprintf(subtitle, sizeof(subtitle), "%s", m->cpu.model[0] ? m->cpu.model : "CPU");
            g_snprintf(stat0, sizeof(stat0), "%.0f%% usage", m->cpu.usage_percent);
            format_temperature(m->cpu.temperature_c, stat1, sizeof(stat1));
            g_snprintf(stat2, sizeof(stat2), "%d cores", m->cpu.cores);
            g_snprintf(stat3, sizeof(stat3), "%d threads", m->cpu.threads);
            format_temperature(m->cpu.temperature_c, temp, sizeof(temp));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Model", m->cpu.model[0] ? m->cpu.model : "Unknown"));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Family", m->cpu.family[0] ? m->cpu.family : "Unknown"));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Generation", m->cpu.generation[0] ? m->cpu.generation : "Unknown"));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Usage", stat0));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Temperature", temp));
            break;
        }
        case PANEL_MEMORY: {
            char total[64], used[64];
            human_bytes(m->memory.total_kb * 1024ULL, total, sizeof(total));
            human_bytes(m->memory.used_kb * 1024ULL, used, sizeof(used));
            g_snprintf(subtitle, sizeof(subtitle), "RAM + swap overview");
            g_snprintf(stat0, sizeof(stat0), "%.0f%% used", m->memory.used_percent);
            g_snprintf(stat1, sizeof(stat1), "%s total", total);
            g_snprintf(stat2, sizeof(stat2), "%.1f MB/s in", m->memory.read_mb_s);
            g_snprintf(stat3, sizeof(stat3), "%.1f MB/s out", m->memory.write_mb_s);
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Pool", "RAM + swap"));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Used", used));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Total", total));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Read", stat2));
            gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("Write", stat3));
            break;
        }
        case PANEL_STORAGE: {
            size_t removable_count = 0;
            for (size_t i = 0; i < m->storage_count; ++i) {
                if (m->storage[i].removable) removable_count++;
            }
            g_snprintf(subtitle, sizeof(subtitle), "%zu device(s): %zu internal, %zu removable", m->storage_count, m->storage_count - removable_count, removable_count);
            if (m->storage_count > 0) {
                g_snprintf(stat0, sizeof(stat0), "%s %s", m->storage[0].transport[0] ? m->storage[0].transport : "Disk", m->storage[0].name);
                g_snprintf(stat1, sizeof(stat1), "%.0f%% used", m->storage[0].used_percent);
                g_snprintf(stat2, sizeof(stat2), "%.0f KB/s R", m->storage[0].read_kbps);
                g_snprintf(stat3, sizeof(stat3), "%.0f KB/s W", m->storage[0].write_kbps);
            }
            bool printed_internal_header = false;
            bool printed_removable_header = false;
            for (size_t i = 0; i < m->storage_count; ++i) {
                char row_value[512];
                char total[64], used[64], temp[64];
                if (m->storage[i].removable && !printed_removable_header) {
                    gtk_box_append(GTK_BOX(state->detail_view), make_section_label("Removable"));
                    printed_removable_header = true;
                } else if (!m->storage[i].removable && !printed_internal_header) {
                    gtk_box_append(GTK_BOX(state->detail_view), make_section_label("Internal"));
                    printed_internal_header = true;
                }
                human_bytes(m->storage[i].total_bytes, total, sizeof(total));
                human_bytes(m->storage[i].used_bytes, used, sizeof(used));
                format_temperature(m->storage[i].temp_c, temp, sizeof(temp));
                g_snprintf(row_value, sizeof(row_value), "%s | %s | %s | %s | FW %s | %.0f%% | %.0fR %.0fW KB/s | %s | %s",
                           m->storage[i].name,
                           m->storage[i].model[0] ? m->storage[i].model : "Unknown model",
                           m->storage[i].vendor[0] ? m->storage[i].vendor : "Unknown vendor",
                           used,
                           m->storage[i].firmware[0] ? m->storage[i].firmware : "n/a",
                           m->storage[i].used_percent,
                           m->storage[i].read_kbps, m->storage[i].write_kbps,
                           temp,
                           m->storage[i].mounts[0] ? m->storage[i].mounts : "no mounts");
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row(m->storage[i].transport[0] ? m->storage[i].transport : m->storage[i].name, row_value));
                g_snprintf(row_value, sizeof(row_value), "%s total | %s | %s",
                           total,
                           m->storage[i].firmware[0] ? m->storage[i].firmware : "n/a",
                           m->storage[i].fs_type[0] ? m->storage[i].fs_type : "fs?");
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("  meta", row_value));
            }
            break;
        }
        case PANEL_NETWORK: {
            size_t tether_count = 0;
            for (size_t i = 0; i < m->network_count; ++i) {
                if (m->network[i].phone_tethering) tether_count++;
            }
            g_snprintf(subtitle, sizeof(subtitle), "%zu interface(s), %zu phone tethering", m->network_count, tether_count);
            if (m->network_count > 0) {
                g_snprintf(stat0, sizeof(stat0), "%s %s", m->network[0].kind[0] ? m->network[0].kind : "Net", m->network[0].name);
                g_snprintf(stat1, sizeof(stat1), "%.1f KB/s rx", m->network[0].rx_kbps);
                g_snprintf(stat2, sizeof(stat2), "%.1f KB/s tx", m->network[0].tx_kbps);
                g_snprintf(stat3, sizeof(stat3), "%s", m->network[0].operstate[0] ? m->network[0].operstate : "unknown");
            }
            for (size_t i = 0; i < m->network_count; ++i) {
                char row_value[384];
                g_snprintf(row_value, sizeof(row_value), "%s%s%s | %.1f KB/s down | %.1f KB/s up | %s | IPv4 %s | MAC %s",
                           m->network[i].kind[0] ? m->network[i].kind : "Interface",
                           m->network[i].usb_backed ? " | USB" : "",
                           m->network[i].phone_tethering ? " | phone" : "",
                           m->network[i].rx_kbps, m->network[i].tx_kbps,
                           m->network[i].operstate[0] ? m->network[i].operstate : "unknown",
                           m->network[i].ipv4[0] ? m->network[i].ipv4 : "n/a",
                           m->network[i].mac[0] ? m->network[i].mac : "n/a");
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row(m->network[i].name, row_value));
                if (m->network[i].ipv6[0]) {
                    gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("  ipv6", m->network[i].ipv6));
                }
            }
            break;
        }
        case PANEL_FANS: {
            g_snprintf(subtitle, sizeof(subtitle), "%zu detected fan(s)", m->fan_count);
            if (m->fan_count > 0) {
                g_snprintf(stat0, sizeof(stat0), "%s", m->fans[0].label);
                g_snprintf(stat1, sizeof(stat1), "%d RPM", m->fans[0].rpm);
            }
            for (size_t i = 0; i < m->fan_count; ++i) {
                char rpm[64];
                g_snprintf(rpm, sizeof(rpm), "%d RPM", m->fans[i].rpm);
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row(m->fans[i].label, rpm));
            }
            break;
        }
        case PANEL_GPU: {
            g_snprintf(subtitle, sizeof(subtitle), "%zu GPU device(s)", m->gpu_count);
            if (m->gpu_count > 0) {
                g_snprintf(stat0, sizeof(stat0), "%s", m->gpus[0].vendor);
                if (m->gpus[0].usage_percent >= 0) g_snprintf(stat1, sizeof(stat1), "%.0f%% usage", m->gpus[0].usage_percent);
                if (m->gpus[0].temperature_c >= 0) g_snprintf(stat2, sizeof(stat2), "%.0f C", m->gpus[0].temperature_c);
            }
            for (size_t i = 0; i < m->gpu_count; ++i) {
                char usage[64], temp[64];
                if (m->gpus[i].usage_percent >= 0) g_snprintf(usage, sizeof(usage), "%.0f%%", m->gpus[i].usage_percent);
                else g_snprintf(usage, sizeof(usage), "Unavailable");
                format_temperature(m->gpus[i].temperature_c, temp, sizeof(temp));
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row(m->gpus[i].name, m->gpus[i].vendor[0] ? m->gpus[i].vendor : "Unknown vendor"));
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("  usage", usage));
                gtk_box_append(GTK_BOX(state->detail_view), make_detail_row("  temp", temp));
            }
            break;
        }
        default:
            break;
    }

    set_stats(state, stat0, stat1, stat2, stat3);
    gtk_label_set_text(GTK_LABEL(state->subtitle_label), subtitle);
    gtk_widget_queue_draw(state->graph_area);
}

static void update_sidebar(AppState *state) {
    Metrics *m = &state->metrics;
    char row1[PANEL_COUNT][128];
    char row2[PANEL_COUNT][128];

    g_snprintf(row1[PANEL_CPU], sizeof(row1[PANEL_CPU]), "%.0f%%", m->cpu.usage_percent);
    g_snprintf(row2[PANEL_CPU], sizeof(row2[PANEL_CPU]), m->cpu.temperature_c >= 0 ? "%.0f C" : "Temp n/a", m->cpu.temperature_c);
    g_snprintf(row1[PANEL_MEMORY], sizeof(row1[PANEL_MEMORY]), "%.0f%% used", m->memory.used_percent);
    g_snprintf(row2[PANEL_MEMORY], sizeof(row2[PANEL_MEMORY]), "%.1f / %.1f GiB", (double)m->memory.used_kb / 1024.0 / 1024.0, (double)m->memory.total_kb / 1024.0 / 1024.0);
    g_snprintf(row1[PANEL_STORAGE], sizeof(row1[PANEL_STORAGE]), "%zu device(s)", m->storage_count);
    g_snprintf(row2[PANEL_STORAGE], sizeof(row2[PANEL_STORAGE]), m->storage_count > 0 ? "%s | %.0f%%" : "No disks", m->storage_count > 0 ? m->storage[0].transport : "", m->storage_count > 0 ? m->storage[0].used_percent : 0.0);
    g_snprintf(row1[PANEL_NETWORK], sizeof(row1[PANEL_NETWORK]), "%zu iface(s)", m->network_count);
    g_snprintf(row2[PANEL_NETWORK], sizeof(row2[PANEL_NETWORK]), m->network_count > 0 ? "%s | %.1f/%.1f KB/s" : "Idle", m->network_count > 0 ? m->network[0].kind : "", m->network_count > 0 ? m->network[0].rx_kbps : 0.0, m->network_count > 0 ? m->network[0].tx_kbps : 0.0);
    g_snprintf(row1[PANEL_FANS], sizeof(row1[PANEL_FANS]), "%zu fan(s)", m->fan_count);
    g_snprintf(row2[PANEL_FANS], sizeof(row2[PANEL_FANS]), m->fan_count > 0 ? "%d RPM" : "No fan data", m->fan_count > 0 ? m->fans[0].rpm : 0);
    g_snprintf(row1[PANEL_GPU], sizeof(row1[PANEL_GPU]), "%zu GPU(s)", m->gpu_count);
    g_snprintf(row2[PANEL_GPU], sizeof(row2[PANEL_GPU]), m->gpu_count > 0 ? "%s" : "No GPU metrics", m->gpu_count > 0 ? m->gpus[0].vendor : "");

    for (int idx = 0; idx < PANEL_COUNT; ++idx) {
        GtkWidget *child = state->sidebar_buttons[idx];
        GtkWidget *box = gtk_widget_get_first_child(child);
        GtkWidget *vbox = gtk_widget_get_last_child(box);
        GtkWidget *title = gtk_widget_get_first_child(vbox);
        GtkWidget *sub1 = gtk_widget_get_next_sibling(title);
        GtkWidget *sub2 = gtk_widget_get_next_sibling(sub1);
        gtk_label_set_text(GTK_LABEL(title), panel_names[idx]);
        gtk_label_set_text(GTK_LABEL(sub1), row1[idx]);
        gtk_label_set_text(GTK_LABEL(sub2), row2[idx]);
        if ((PanelType)idx == state->current_panel) gtk_widget_add_css_class(child, "active-panel");
        else gtk_widget_remove_css_class(child, "active-panel");
    }
}

static void update_sidebar_extras(AppState *state) {
    for (int idx = 0; idx < PANEL_COUNT; ++idx) {
        clear_box(state->sidebar_extras[idx]);
    }

    for (size_t i = 0; i < state->metrics.storage_count && i < 4; ++i) {
        char text[128];
        g_snprintf(text, sizeof(text), "%s %s", state->metrics.storage[i].transport[0] ? state->metrics.storage[i].transport : "Disk", state->metrics.storage[i].name);
        gtk_box_append(GTK_BOX(state->sidebar_extras[PANEL_STORAGE]), make_compact_chip(text));
    }
    for (size_t i = 0; i < state->metrics.network_count && i < 4; ++i) {
        char text[128];
        g_snprintf(text, sizeof(text), "%s %s", state->metrics.network[i].name, state->metrics.network[i].kind[0] ? state->metrics.network[i].kind : "");
        gtk_box_append(GTK_BOX(state->sidebar_extras[PANEL_NETWORK]), make_compact_chip(text));
    }
    for (size_t i = 0; i < state->metrics.gpu_count && i < 3; ++i) {
        gtk_box_append(GTK_BOX(state->sidebar_extras[PANEL_GPU]), make_compact_chip(state->metrics.gpus[i].vendor[0] ? state->metrics.gpus[i].vendor : state->metrics.gpus[i].name));
    }
    for (size_t i = 0; i < state->metrics.fan_count && i < 3; ++i) {
        gtk_box_append(GTK_BOX(state->sidebar_extras[PANEL_FANS]), make_compact_chip(state->metrics.fans[i].label));
    }
}

static void update_topbar(AppState *state) {
    for (int i = 0; i < SECTION_COUNT; ++i) {
        if ((TopSection)i == state->current_section) {
            gtk_widget_remove_css_class(state->top_buttons[i], "top-chip");
            gtk_widget_add_css_class(state->top_buttons[i], "top-chip-active");
        } else {
            gtk_widget_remove_css_class(state->top_buttons[i], "top-chip-active");
            gtk_widget_add_css_class(state->top_buttons[i], "top-chip");
        }
    }
}

static void update_mode_buttons(AppState *state) {
    for (int i = 0; i < VIEW_COUNT; ++i) {
        if ((ViewMode)i == state->current_view) {
            gtk_widget_remove_css_class(state->mode_buttons[i], "mode-chip");
            gtk_widget_add_css_class(state->mode_buttons[i], "mode-chip-active");
        } else {
            gtk_widget_remove_css_class(state->mode_buttons[i], "mode-chip-active");
            gtk_widget_add_css_class(state->mode_buttons[i], "mode-chip");
        }
    }
}

static void graph_draw(GtkDrawingArea *area, cairo_t *cr, int width, int height, gpointer data) {
    (void)area;
    AppState *state = data;
    PanelType panel = state->current_panel;

    cairo_set_source_rgb(cr, 0.11, 0.11, 0.13);
    cairo_paint(cr);

    cairo_set_source_rgba(cr, 0.45, 0.18, 0.65, 0.25);
    for (int i = 0; i <= 8; ++i) {
        double y = (double)i * height / 8.0;
        cairo_move_to(cr, 0, y);
        cairo_line_to(cr, width, y);
    }
    for (int i = 0; i <= 16; ++i) {
        double x = (double)i * width / 16.0;
        cairo_move_to(cr, x, 0);
        cairo_line_to(cr, x, height);
    }
    cairo_set_line_width(cr, 1.0);
    cairo_stroke(cr);

    size_t len = state->history_len[panel];
    if (len < 2) return;

    double current_value = len > 0 ? state->history[panel][(state->history_head[panel] + HISTORY_SIZE - 1) % HISTORY_SIZE] : 0.0;
    GdkRGBA accent = accent_for_value(panel, current_value);
    double x_step = (double)width / (double)(HISTORY_SIZE - 1);

    cairo_move_to(cr, 0, height);
    for (size_t i = 0; i < len; ++i) {
        size_t hist_idx = (state->history_head[panel] + HISTORY_SIZE - len + i) % HISTORY_SIZE;
        double value = clamp_percent(state->history[panel][hist_idx]);
        double x = i * x_step;
        double y = height - (value / 100.0) * height;
        cairo_line_to(cr, x, y);
    }
    cairo_line_to(cr, (len - 1) * x_step, height);
    cairo_close_path(cr);
    cairo_set_source_rgba(cr, accent.red, accent.green, accent.blue, 0.24);
    cairo_fill_preserve(cr);
    cairo_set_source_rgba(cr, accent.red, accent.green, accent.blue, 0.95);
    cairo_set_line_width(cr, 2.0);
    cairo_stroke(cr);
}

static void sidebar_graph_draw(GtkDrawingArea *area, cairo_t *cr, int width, int height, gpointer data) {
    AppState *state = data;
    PanelType panel = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(area), "panel-id"));
    cairo_set_source_rgba(cr, 1, 1, 1, 0.0);
    cairo_paint(cr);

    size_t len = state->history_len[panel];
    if (len < 2) return;

    double current_value = len > 0 ? state->history[panel][(state->history_head[panel] + HISTORY_SIZE - 1) % HISTORY_SIZE] : 0.0;
    GdkRGBA accent = accent_for_value(panel, current_value);
    double x_step = (double)width / (double)(HISTORY_SIZE - 1);

    cairo_move_to(cr, 0, height);
    for (size_t i = 0; i < len; ++i) {
        size_t hist_idx = (state->history_head[panel] + HISTORY_SIZE - len + i) % HISTORY_SIZE;
        double value = clamp_percent(state->history[panel][hist_idx]);
        double x = i * x_step;
        double y = height - (value / 100.0) * height;
        cairo_line_to(cr, x, y);
    }
    cairo_line_to(cr, (len - 1) * x_step, height);
    cairo_close_path(cr);
    cairo_set_source_rgba(cr, accent.red, accent.green, accent.blue, 0.18);
    cairo_fill_preserve(cr);
    cairo_set_source_rgba(cr, accent.red, accent.green, accent.blue, 0.95);
    cairo_set_line_width(cr, 1.6);
    cairo_stroke(cr);
}

static gboolean refresh_ui(gpointer data) {
    AppState *state = data;
    collect_metrics(state);
    update_sidebar(state);
    update_sidebar_extras(state);
    update_topbar(state);
    update_mode_buttons(state);
    refresh_detail_panel(state);
    for (int i = 0; i < PANEL_COUNT; ++i) {
        GtkWidget *button = state->sidebar_buttons[i];
        GtkWidget *row = gtk_widget_get_first_child(button);
        GtkWidget *media = gtk_widget_get_first_child(row);
        GtkWidget *spark = gtk_widget_get_last_child(media);
        gtk_widget_queue_draw(spark);
    }
    return G_SOURCE_CONTINUE;
}

static void on_sidebar_clicked(GtkButton *button, gpointer data) {
    AppState *state = data;
    state->current_panel = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(button), "panel-id"));
    state->current_section = section_for_panel(state->current_panel);
    update_topbar(state);
    refresh_detail_panel(state);
}

static void on_mode_clicked(GtkButton *button, gpointer data) {
    AppState *state = data;
    state->current_view = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(button), "view-id"));
    update_mode_buttons(state);
    refresh_detail_panel(state);
}

static void on_topbar_clicked(GtkButton *button, gpointer data) {
    AppState *state = data;
    TopSection section = GPOINTER_TO_INT(g_object_get_data(G_OBJECT(button), "section-id"));
    state->current_section = section;
    switch (section) {
        case SECTION_PERFORMANCE:
            state->current_panel = PANEL_CPU;
            break;
        case SECTION_DEVICES:
            state->current_panel = PANEL_STORAGE;
            break;
        case SECTION_SERVICES:
            state->current_panel = PANEL_FANS;
            break;
        default:
            break;
    }
    update_topbar(state);
    refresh_detail_panel(state);
}

static GtkWidget *create_sidebar_item(AppState *state, PanelType panel) {
    GtkWidget *container = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    GtkWidget *button = gtk_button_new();
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    GtkWidget *media = gtk_box_new(GTK_ORIENTATION_VERTICAL, 6);
    GtkWidget *badge = gtk_label_new(panel_badges[panel]);
    GtkWidget *spark = gtk_drawing_area_new();
    GtkWidget *text = gtk_box_new(GTK_ORIENTATION_VERTICAL, 2);
    GtkWidget *title = gtk_label_new(panel_names[panel]);
    GtkWidget *sub1 = gtk_label_new("");
    GtkWidget *sub2 = gtk_label_new("");

    gtk_widget_set_size_request(spark, 56, 18);
    gtk_widget_add_css_class(spark, "spark");
    gtk_widget_add_css_class(badge, "badge");
    gtk_widget_set_hexpand(text, true);
    gtk_widget_set_halign(title, GTK_ALIGN_START);
    gtk_widget_set_halign(sub1, GTK_ALIGN_START);
    gtk_widget_set_halign(sub2, GTK_ALIGN_START);
    gtk_widget_set_halign(badge, GTK_ALIGN_CENTER);
    gtk_widget_add_css_class(title, "sidebar-title");
    gtk_widget_add_css_class(sub1, "sidebar-sub");
    gtk_widget_add_css_class(sub2, "sidebar-sub");
    g_object_set_data(G_OBJECT(spark), "panel-id", GINT_TO_POINTER(panel));
    gtk_drawing_area_set_draw_func(GTK_DRAWING_AREA(spark), sidebar_graph_draw, state, NULL);

    gtk_box_append(GTK_BOX(text), title);
    gtk_box_append(GTK_BOX(text), sub1);
    gtk_box_append(GTK_BOX(text), sub2);
    gtk_box_append(GTK_BOX(media), badge);
    gtk_box_append(GTK_BOX(media), spark);
    gtk_box_append(GTK_BOX(row), media);
    gtk_box_append(GTK_BOX(row), text);
    gtk_button_set_child(GTK_BUTTON(button), row);
    gtk_widget_add_css_class(button, "sidebar-item");

    g_object_set_data(G_OBJECT(button), "panel-id", GINT_TO_POINTER(panel));
    g_signal_connect(button, "clicked", G_CALLBACK(on_sidebar_clicked), state);
    GtkWidget *extras = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);
    gtk_widget_add_css_class(extras, "extras-row");
    gtk_box_append(GTK_BOX(container), button);
    gtk_box_append(GTK_BOX(container), extras);
    state->sidebar_buttons[panel] = button;
    state->sidebar_extras[panel] = extras;
    return container;
}

static GtkWidget *make_top_chip(AppState *state, const char *text, TopSection section, gboolean active) {
    GtkWidget *button = gtk_button_new_with_label(text);
    gtk_widget_add_css_class(button, active ? "top-chip-active" : "top-chip");
    g_object_set_data(G_OBJECT(button), "section-id", GINT_TO_POINTER(section));
    g_signal_connect(button, "clicked", G_CALLBACK(on_topbar_clicked), state);
    state->top_buttons[section] = button;
    return button;
}

static GtkWidget *make_mode_chip(AppState *state, const char *text, ViewMode view, gboolean active) {
    GtkWidget *button = gtk_button_new_with_label(text);
    gtk_widget_add_css_class(button, active ? "mode-chip-active" : "mode-chip");
    g_object_set_data(G_OBJECT(button), "view-id", GINT_TO_POINTER(view));
    g_signal_connect(button, "clicked", G_CALLBACK(on_mode_clicked), state);
    state->mode_buttons[view] = button;
    return button;
}

static void activate(GtkApplication *app, gpointer user_data) {
    AppState *state = user_data;
    state->app = app;
    state->refresh_interval_ms = 1000;
    state->current_panel = PANEL_CPU;
    state->current_section = SECTION_PERFORMANCE;
    state->current_view = VIEW_DEFAULT;

    GtkCssProvider *css = gtk_css_provider_new();
    gtk_css_provider_load_from_string(css,
        "window { background: #16181d; color: #f5f7fb; }"
        ".shell { padding: 18px; }"
        ".sidebar { background: linear-gradient(180deg, #22262d 0%, #1c2027 100%); border-radius: 24px; padding: 14px; min-width: 300px; }"
        ".sidebar-header { font-size: 32px; font-weight: 800; }"
        ".sidebar-muted { color: rgba(255,255,255,0.58); font-size: 14px; }"
        ".sidebar-item { background: transparent; border-radius: 18px; padding: 12px; }"
        ".sidebar-item:hover { background: rgba(255,255,255,0.05); }"
        ".active-panel { background: rgba(255,255,255,0.09); box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04); }"
        ".badge { background: rgba(255,255,255,0.08); color: #ffffff; border-radius: 999px; padding: 4px 8px; font-size: 11px; font-weight: 800; }"
        ".mini-chip { background: rgba(255,255,255,0.05); color: rgba(255,255,255,0.72); border-radius: 999px; padding: 4px 8px; font-size: 11px; font-weight: 700; }"
        ".extras-row { margin-left: 72px; }"
        ".sidebar-title { font-size: 22px; font-weight: 700; }"
        ".sidebar-sub { color: rgba(255,255,255,0.70); font-size: 14px; }"
        ".spark { background: #20242b; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; }"
        ".content { padding: 4px 8px; }"
        ".topbar { padding: 2px 0 6px 0; }"
        ".top-chip, .top-chip-active { border-radius: 999px; padding: 8px 14px; font-weight: 700; }"
        ".top-chip { background: rgba(255,255,255,0.04); color: rgba(255,255,255,0.70); }"
        ".top-chip-active { background: rgba(255,255,255,0.10); color: #ffffff; }"
        ".mode-chip, .mode-chip-active { border-radius: 999px; padding: 8px 14px; font-weight: 700; }"
        ".mode-chip { background: rgba(255,255,255,0.04); color: rgba(255,255,255,0.65); }"
        ".mode-chip-active { background: rgba(75,163,255,0.18); color: #ffffff; }"
        ".headline { font-size: 42px; font-weight: 800; letter-spacing: -0.02em; }"
        ".subheadline { font-size: 17px; color: rgba(255,255,255,0.72); }"
        ".stats-row { margin-top: 2px; }"
        ".stat-card { background: linear-gradient(180deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.035) 100%); border-radius: 20px; padding: 16px; min-width: 168px; box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04); }"
        ".dim-label { color: rgba(255,255,255,0.52); font-size: 13px; text-transform: uppercase; }"
        ".stat-value { font-size: 24px; font-weight: 800; }"
        ".graph-frame { background: linear-gradient(180deg, #1d2128 0%, #191c22 100%); border-radius: 22px; padding: 16px; box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04); }"
        ".detail-card { background: linear-gradient(180deg, rgba(255,255,255,0.045) 0%, rgba(255,255,255,0.025) 100%); border-radius: 22px; padding: 16px; box-shadow: inset 0 0 0 1px rgba(255,255,255,0.04); }"
        ".section-label { color: rgba(255,255,255,0.46); font-size: 12px; font-weight: 800; text-transform: uppercase; margin-top: 12px; margin-bottom: 2px; }"
        ".detail-row { background: rgba(255,255,255,0.025); border-radius: 14px; padding: 8px 12px; }"
        ".detail-key { color: rgba(255,255,255,0.64); font-size: 14px; }"
        ".detail-value { font-weight: 700; font-size: 14px; }"
        ".mono-block { font-family: monospace; font-size: 14px; background: rgba(255,255,255,0.03); border-radius: 14px; padding: 14px; }");
    gtk_style_context_add_provider_for_display(gdk_display_get_default(), GTK_STYLE_PROVIDER(css), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    state->window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(state->window), "TaskCommander");
    gtk_window_set_default_size(GTK_WINDOW(state->window), 1540, 900);

    GtkWidget *root = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 16);
    gtk_widget_add_css_class(root, "shell");
    gtk_window_set_child(GTK_WINDOW(state->window), root);

    GtkWidget *sidebar_frame = gtk_box_new(GTK_ORIENTATION_VERTICAL, 12);
    gtk_widget_add_css_class(sidebar_frame, "sidebar");
    gtk_box_append(GTK_BOX(root), sidebar_frame);

    GtkWidget *sidebar_title = gtk_label_new("Devices");
    GtkWidget *sidebar_subtitle = gtk_label_new("Live hardware overview");
    gtk_widget_set_halign(sidebar_title, GTK_ALIGN_START);
    gtk_widget_set_halign(sidebar_subtitle, GTK_ALIGN_START);
    gtk_widget_add_css_class(sidebar_title, "sidebar-header");
    gtk_widget_add_css_class(sidebar_subtitle, "sidebar-muted");
    gtk_widget_set_margin_bottom(sidebar_subtitle, 8);
    gtk_box_append(GTK_BOX(sidebar_frame), sidebar_title);
    gtk_box_append(GTK_BOX(sidebar_frame), sidebar_subtitle);

    GtkWidget *sidebar_scroll = gtk_scrolled_window_new();
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sidebar_scroll), GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
    gtk_widget_set_vexpand(sidebar_scroll, true);
    state->sidebar = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_scrolled_window_set_child(GTK_SCROLLED_WINDOW(sidebar_scroll), state->sidebar);
    gtk_box_append(GTK_BOX(sidebar_frame), sidebar_scroll);
    for (int i = 0; i < PANEL_COUNT; ++i) {
        gtk_box_append(GTK_BOX(state->sidebar), create_sidebar_item(state, (PanelType)i));
    }

    GtkWidget *content = gtk_box_new(GTK_ORIENTATION_VERTICAL, 16);
    gtk_widget_add_css_class(content, "content");
    gtk_box_append(GTK_BOX(root), content);

    GtkWidget *topbar = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_widget_add_css_class(topbar, "topbar");
    gtk_box_append(GTK_BOX(topbar), make_top_chip(state, "Performance", SECTION_PERFORMANCE, TRUE));
    gtk_box_append(GTK_BOX(topbar), make_top_chip(state, "Devices", SECTION_DEVICES, FALSE));
    gtk_box_append(GTK_BOX(topbar), make_top_chip(state, "Services", SECTION_SERVICES, FALSE));
    GtkWidget *mode_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 8);
    gtk_widget_set_hexpand(mode_box, true);
    gtk_widget_set_halign(mode_box, GTK_ALIGN_END);
    gtk_box_append(GTK_BOX(mode_box), make_mode_chip(state, view_names[VIEW_DEFAULT], VIEW_DEFAULT, TRUE));
    gtk_box_append(GTK_BOX(mode_box), make_mode_chip(state, view_names[VIEW_HTOP], VIEW_HTOP, FALSE));
    gtk_box_append(GTK_BOX(topbar), mode_box);
    gtk_box_append(GTK_BOX(content), topbar);

    state->title_label = gtk_label_new("Processor");
    gtk_widget_add_css_class(state->title_label, "headline");
    gtk_widget_set_halign(state->title_label, GTK_ALIGN_START);
    state->subtitle_label = gtk_label_new("");
    gtk_widget_add_css_class(state->subtitle_label, "subheadline");
    gtk_widget_set_halign(state->subtitle_label, GTK_ALIGN_START);
    gtk_box_append(GTK_BOX(content), state->title_label);
    gtk_box_append(GTK_BOX(content), state->subtitle_label);

    GtkWidget *stats = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    gtk_widget_add_css_class(stats, "stats-row");
    state->stats_row = stats;
    for (int i = 0; i < 4; ++i) {
        GtkWidget *card = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
        gtk_widget_add_css_class(card, "stat-card");
        GtkWidget *row = make_stat_row(i == 0 ? "Primary" : i == 1 ? "Secondary" : i == 2 ? "Third" : "Fourth", "");
        state->stat_labels[i] = gtk_widget_get_last_child(row);
        gtk_box_append(GTK_BOX(card), row);
        gtk_box_append(GTK_BOX(stats), card);
    }
    gtk_box_append(GTK_BOX(content), stats);

    GtkWidget *graph_frame = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_add_css_class(graph_frame, "graph-frame");
    state->graph_frame = graph_frame;
    state->graph_area = gtk_drawing_area_new();
    gtk_drawing_area_set_content_width(GTK_DRAWING_AREA(state->graph_area), 960);
    gtk_drawing_area_set_content_height(GTK_DRAWING_AREA(state->graph_area), 320);
    gtk_drawing_area_set_draw_func(GTK_DRAWING_AREA(state->graph_area), graph_draw, state, NULL);
    gtk_box_append(GTK_BOX(graph_frame), state->graph_area);
    gtk_box_append(GTK_BOX(content), graph_frame);

    GtkWidget *detail_card = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_widget_add_css_class(detail_card, "detail-card");
    state->detail_view = gtk_box_new(GTK_ORIENTATION_VERTICAL, 8);
    gtk_box_append(GTK_BOX(detail_card), state->detail_view);
    gtk_box_append(GTK_BOX(content), detail_card);

    collect_metrics(state);
    update_sidebar(state);
    refresh_detail_panel(state);
    state->timer_id = g_timeout_add(state->refresh_interval_ms, refresh_ui, state);

    gtk_window_present(GTK_WINDOW(state->window));
}

int taskcommander_run(int argc, char **argv) {
    AppState state = {0};
    GtkApplication *app = gtk_application_new("local.taskcommander.monitor", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(activate), &state);
    int status = g_application_run(G_APPLICATION(app), argc, argv);
    if (state.timer_id) g_source_remove(state.timer_id);
    g_object_unref(app);
    return status;
}
